package co.edu.createmessageactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CreateMessageActivity extends AppCompatActivity {
    Button button;
    EditText txtMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_message);

        button = findViewById(R.id.button);




    }

    public void onSendMessage(View view){
        txtMessage = findViewById(R.id.createMessage_text);
        String message = txtMessage.getText().toString();
        Intent intent = new Intent(getApplicationContext(),ReceiveMessageActivity.class);
        intent.putExtra(ReceiveMessageActivity.EXTRA_MESSAGE,message);
        startActivity(intent);
    }
}